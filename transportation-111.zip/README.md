# Traffic forecasting
Problems:
- traffic intensity forecasting
- 

# Установка и запуск

1. Настройка локального окружения 

Для запуска python файлов необходимо создать виртуальное окружение и установить зависимости

```code(sh)
python3 -m venv venv # создание локального виртуального окружения
. venv/bin/activate # активация окружения (Linux)

или 

.\venv\Scripts\activate # (Windows)

pip install --editable . # установка зависимостей
```

2. Запуск 

```
run
```

Запускает точку входа в консольное приложение. При успешном запуске выведет список доступных команд 